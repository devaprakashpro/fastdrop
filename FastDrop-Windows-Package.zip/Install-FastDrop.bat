@echo off
rem Right-click -> Run as administrator (needed once for the firewall rule)
set DEST=%LOCALAPPDATA%\FastDrop
mkdir "%DEST%" 2>nul
copy /y "%~dp0FastDrop.exe" "%DEST%\FastDrop.exe" >nul
netsh advfirewall firewall delete rule name="FastDrop" >nul 2>&1
netsh advfirewall firewall add rule name="FastDrop" dir=in action=allow program="%DEST%\FastDrop.exe" enable=yes profile=private,public >nul
netsh advfirewall firewall add rule name="FastDrop discovery" dir=in action=allow protocol=UDP localport=8766 profile=private,public >nul
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\FastDrop.lnk');$s.TargetPath='%DEST%\FastDrop.exe';$s.Save()"
echo Installed. Desktop shortcut "FastDrop" created.
start "" "%DEST%\FastDrop.exe"
pause
