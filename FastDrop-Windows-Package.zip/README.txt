FastDrop - quick file share between a Windows PC and an Android phone (same Wi-Fi, optional USB cable)
Full guide: README.md  |  developer notes: docs/DEVELOPER.md  (both inside this package)

INSTALL
  PC:    right-click Install-FastDrop.bat -> Run as administrator (once).
         (copies the app, opens the firewall, adds a desktop shortcut)
         SmartScreen warning: More info -> Run anyway (the exe is unsigned).
  PHONE: install FastDrop.apk, allow notifications.

CONNECT
  Open FastDrop on both. On the PC window click "Scan to connect" (it shows a QR code);
  on the phone tap "Scan QR to connect". Or just wait: they also find each other on the same Wi-Fi.

USE
  Drag files into the PC window -> they arrive on the phone.  Phone: "Send files to PC" or Share -> FastDrop.
  Folder icon on a received file / "Open received files" opens it in the file manager.
  Received: PC Downloads\FastDrop | phone Download/FastDrop

USB CABLE TOO (Wi-Fi + cable at once, about +60% speed) - optional
  1. Phone: Developer options -> USB debugging ON.
  2. PC: install Android platform-tools (adb), adb.exe on PATH or next to FastDrop.exe.
  3. Plug in, tap Allow on the phone. The phone then shows "Cable active".
  Modes on the phone: Wi-Fi + Cable (default) / Wi-Fi only / Cable only. A USB 3 cable is much faster.
